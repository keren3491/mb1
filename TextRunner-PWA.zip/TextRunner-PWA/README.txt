TextRunner PWA

How to use on iPhone:
1. Put these files on any HTTPS website (GitHub Pages works).
2. Open index.html in Safari.
3. Tap Share → Add to Home Screen.
4. Launch TextRunner from the icon.

Important iPhone limits:
- A web app cannot silently read all iPhone contacts on every iOS/Safari version.
- A web app cannot automatically press Send in Messages.
- TextRunner opens one pre-filled SMS at a time. You tap Send, return to TextRunner, then tap Next Message.

Included:
- Home Screen install support
- Offline shell via service worker
- Message templates with {FirstName} and {FullName}
- Manual contacts
- Contact Picker API attempt where supported
- First/Next/Previous 100
- Select All/Clear
- Delay setting
- Start/Pause/Resume/Stop
- Progress tracking
